using System;
using System.Collections.Generic;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using Lab13.BUS;

namespace Lab13_CrystalReport;

public sealed class MainForm : Form
{
    private static readonly Color Navy = Color.FromArgb(25, 63, 110);
    private static readonly Color Teal = Color.FromArgb(16, 129, 102);
    private static readonly Color Amber = Color.FromArgb(184, 110, 18);
    private static readonly Color Background = Color.FromArgb(238, 242, 248);
    private static readonly Color Muted = Color.FromArgb(100, 112, 128);

    private readonly BaoCaoService _service = new();
    private readonly Dictionary<Type, Form> _openReports = new();

    private readonly Label _lblStudentCount = new();
    private readonly Label _lblFacultyCount = new();
    private readonly Label _lblCourseCount = new();
    private readonly Label _lblDbStatus = new();
    private readonly Label _lblEngineStatus = new();
    private readonly ToolStripStatusLabel _lblStatus = new();

    public MainForm()
    {
        Text = "Lab 13 – Tạo báo cáo cơ bản bằng Crystal Report";
        Size = new Size(1180, 780);
        MinimumSize = new Size(1080, 720);
        StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 9F);
        BackColor = Background;
        KeyPreview = true;

        BuildLayout();

        Load += (_, _) => LoadSummary();
        KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.F5) LoadSummary();
        };
        FormClosing += (_, _) => CloseAllReports();
    }

    private void BuildLayout()
    {
        var content = BuildContent();
        var sidebar = BuildSidebar();
        var header = BuildHeader();
        var status = BuildStatusBar();
        var menu = BuildMenu();

        Controls.Add(content);
        Controls.Add(sidebar);
        Controls.Add(header);
        Controls.Add(status);
        Controls.Add(menu);
        MainMenuStrip = menu;
    }

    private Panel BuildHeader()
    {
        var panel = new Panel
        {
            Dock = DockStyle.Top,
            Height = 116,
            BackColor = Navy,
            Padding = new Padding(26, 14, 26, 10)
        };

        panel.Paint += (_, e) =>
        {
            using var pen = new Pen(Teal, 4);
            e.Graphics.DrawLine(pen, 0, panel.Height - 4, panel.Width, panel.Height - 4);
        };

        var school = new Label
        {
            Text = "TRƯỜNG ĐẠI HỌC CÔNG NGHỆ ĐÔNG Á  •  KHOA CÔNG NGHỆ THÔNG TIN",
            ForeColor = Color.FromArgb(183, 204, 233),
            Font = new Font("Segoe UI", 8.5F, FontStyle.Bold),
            AutoSize = true,
            Location = new Point(26, 14),
            BackColor = Color.Transparent
        };
        var title = new Label
        {
            Text = "LAB 13 – BÁO CÁO CƠ BẢN BẰNG CRYSTAL REPORT",
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 16F, FontStyle.Bold),
            AutoSize = true,
            Location = new Point(23, 40),
            BackColor = Color.Transparent
        };
        var subtitle = new Label
        {
            Text = "Nguồn dữ liệu QLSinhVien  •  CrystalReportViewer  •  Xuất PDF / In ấn",
            ForeColor = Color.FromArgb(198, 214, 236),
            Font = new Font("Segoe UI", 9F),
            AutoSize = true,
            Location = new Point(26, 80),
            BackColor = Color.Transparent
        };
        var student = new Label
        {
            Text = "Sinh viên: Nguyễn Quang Dũng  •  MSSV: 24003351",
            ForeColor = Color.FromArgb(211, 226, 245),
            Font = new Font("Segoe UI", 8.5F, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleRight,
            AutoSize = false,
            Size = new Size(470, 20),
            Location = new Point(660, 12),
            Anchor = AnchorStyles.Top | AnchorStyles.Right,
            BackColor = Color.Transparent
        };
        panel.Resize += (_, _) =>
        {
            student.Location = new Point(panel.ClientSize.Width - student.Width - 26, 12);
        };

        panel.Controls.Add(school);
        panel.Controls.Add(title);
        panel.Controls.Add(subtitle);
        panel.Controls.Add(student);
        return panel;
    }

    private Panel BuildSidebar()
    {
        var panel = new Panel
        {
            Dock = DockStyle.Left,
            Width = 286,
            BackColor = Color.White,
            Padding = new Padding(18, 20, 18, 18)
        };

        var flow = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            AutoScroll = false,
            BackColor = Color.White
        };

        flow.Controls.Add(new Label
        {
            Text = "CHỨC NĂNG BÁO CÁO",
            ForeColor = Muted,
            Font = new Font("Segoe UI", 8F, FontStyle.Bold),
            AutoSize = true,
            Margin = new Padding(4, 0, 0, 8)
        });

        flow.Controls.Add(CreateMenuButton("Tổng quan", true, (_, _) => { }));
        flow.Controls.Add(CreateMenuButton("Báo cáo Sinh viên", false, (_, _) => OpenReport(() => new frmBaoCaoSinhVien())));
        flow.Controls.Add(CreateMenuButton("Báo cáo Khoa", false, (_, _) => OpenReport(() => new frmBaoCaoKhoa())));
        flow.Controls.Add(CreateMenuButton("Báo cáo Học phần", false, (_, _) => OpenReport(() => new frmBaoCaoHocPhan())));

        flow.Controls.Add(new Label
        {
            Text = "CÔNG CỤ",
            ForeColor = Muted,
            Font = new Font("Segoe UI", 8F, FontStyle.Bold),
            AutoSize = true,
            Margin = new Padding(4, 20, 0, 8)
        });

        flow.Controls.Add(CreateMenuButton("Làm mới số liệu  (F5)", false, (_, _) => LoadSummary()));
        flow.Controls.Add(CreateMenuButton("Kiểm tra kết nối CSDL", false, (_, _) => CheckConnection()));
        flow.Controls.Add(CreateMenuButton("Mở thư mục Reports", false, (_, _) => OpenReportsFolder()));
        flow.Controls.Add(CreateMenuButton("Giới thiệu Lab 13", false, (_, _) => ShowAbout()));

        panel.Controls.Add(flow);
        return panel;
    }

    private Button CreateMenuButton(string text, bool active, EventHandler onClick)
    {
        var button = new Button
        {
            Text = "   " + text,
            Width = 244,
            Height = 42,
            FlatStyle = FlatStyle.Flat,
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
            BackColor = active ? Color.FromArgb(231, 239, 250) : Color.White,
            ForeColor = active ? Navy : Color.FromArgb(52, 66, 84),
            Cursor = Cursors.Hand,
            Margin = new Padding(0, 0, 0, 6),
            Padding = new Padding(6, 0, 0, 0)
        };
        button.FlatAppearance.BorderSize = 1;
        button.FlatAppearance.BorderColor = active ? Color.FromArgb(198, 216, 240) : Color.FromArgb(232, 237, 244);
        button.FlatAppearance.MouseOverBackColor = Color.FromArgb(241, 246, 253);
        button.Click += onClick;
        return button;
    }

    private Panel BuildContent()
    {
        var content = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Background,
            Padding = new Padding(26, 20, 26, 16),
            AutoScroll = true
        };

        var title = new Label
        {
            Text = "TỔNG QUAN LAB 13",
            ForeColor = Navy,
            Font = new Font("Segoe UI", 15F, FontStyle.Bold),
            AutoSize = true,
            Location = new Point(26, 18)
        };
        var description = new Label
        {
            Text = "10 bài: view dữ liệu, DataTable, 3 mẫu báo cáo, định dạng A4, menu, in và xuất PDF.",
            ForeColor = Muted,
            Font = new Font("Segoe UI", 9.5F),
            AutoSize = true,
            MaximumSize = new Size(820, 0),
            Location = new Point(28, 50)
        };

        var cards = new FlowLayoutPanel
        {
            Location = new Point(26, 82),
            Size = new Size(820, 112),
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            BackColor = Color.Transparent
        };
        cards.Controls.Add(CreateStatCard("SINH VIÊN", "30", "vw_BaoCaoSinhVien", Navy, _lblStudentCount));
        cards.Controls.Add(CreateStatCard("KHOA", "3", "vw_BaoCaoKhoa", Teal, _lblFacultyCount));
        cards.Controls.Add(CreateStatCard("HỌC PHẦN", "5", "vw_BaoCaoHocPhan", Amber, _lblCourseCount));

        var checklistTitle = new Label
        {
            Text = "TIẾN ĐỘ 10 BÀI THỰC HÀNH",
            ForeColor = Navy,
            Font = new Font("Segoe UI", 10F, FontStyle.Bold),
            AutoSize = true,
            Location = new Point(26, 212)
        };

        var checklist = new FlowLayoutPanel
        {
            Location = new Point(26, 240),
            Size = new Size(820, 118),
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = true,
            BackColor = Color.Transparent
        };

        string[] items =
        [
            "Bài 1 – Môi trường",
            "Bài 2 – View dữ liệu",
            "Bài 3 – DataTable",
            "Bài 4 – Viewer",
            "Bài 5 – Xuất PDF",
            "Bài 6 – Báo cáo Khoa",
            "Bài 7 – Định dạng",
            "Bài 8 – Học phần",
            "Bài 9 – Menu",
            "Bài 10 – Kiểm thử"
        ];
        foreach (var item in items)
        {
            checklist.Controls.Add(CreateCheckChip(item));
        }

        var environment = new Panel
        {
            Location = new Point(26, 374),
            Size = new Size(820, 168),
            BackColor = Color.White,
            Padding = new Padding(18, 14, 18, 12)
        };
        environment.Paint += (_, e) =>
        {
            using var pen = new Pen(Color.FromArgb(222, 229, 239));
            e.Graphics.DrawRectangle(pen, 0, 0, environment.Width - 1, environment.Height - 1);
            using var accent = new SolidBrush(Teal);
            e.Graphics.FillRectangle(accent, 0, 0, 5, environment.Height);
        };

        var envTitle = new Label
        {
            Text = "MÔI TRƯỜNG & KỸ THUẬT",
            ForeColor = Navy,
            Font = new Font("Segoe UI", 9F, FontStyle.Bold),
            AutoSize = true,
            Location = new Point(18, 12),
            BackColor = Color.Transparent
        };

        _lblDbStatus.Text = "SQL Server: đang kiểm tra...";
        _lblDbStatus.ForeColor = Muted;
        _lblDbStatus.Font = new Font("Segoe UI", 9F);
        _lblDbStatus.AutoSize = true;
        _lblDbStatus.MaximumSize = new Size(760, 0);
        _lblDbStatus.Location = new Point(20, 42);
        _lblDbStatus.BackColor = Color.Transparent;

        _lblEngineStatus.Text = "Report engine: " + GetReportEngineDescription();
        _lblEngineStatus.ForeColor = Muted;
        _lblEngineStatus.Font = new Font("Segoe UI", 9F);
        _lblEngineStatus.AutoSize = true;
        _lblEngineStatus.MaximumSize = new Size(760, 0);
        _lblEngineStatus.Location = new Point(20, 68);
        _lblEngineStatus.BackColor = Color.Transparent;

        var layoutInfo = new Label
        {
            Text = "Định dạng: A4 Portrait  •  Lề 40 px  •  Header/Footer, số trang, ngày lập, định dạng dd/MM/yyyy và điểm N2  •  Xuất PDF, HTML, in trực tiếp",
            ForeColor = Muted,
            Font = new Font("Segoe UI", 8.5F),
            AutoSize = true,
            MaximumSize = new Size(760, 0),
            Location = new Point(20, 94),
            BackColor = Color.Transparent
        };

        var hint = new Label
        {
            Text = "Mẹo: mở từng báo cáo, bấm “Thiết kế” để xem bố cục section, bấm “Xuất PDF (Bài 5)” để lưu báo cáo.",
            ForeColor = Teal,
            Font = new Font("Segoe UI", 8.5F, FontStyle.Italic),
            AutoSize = true,
            MaximumSize = new Size(760, 0),
            Location = new Point(20, 134),
            BackColor = Color.Transparent
        };

        environment.Controls.Add(envTitle);
        environment.Controls.Add(_lblDbStatus);
        environment.Controls.Add(_lblEngineStatus);
        environment.Controls.Add(layoutInfo);
        environment.Controls.Add(hint);

        content.Controls.Add(title);
        content.Controls.Add(description);
        content.Controls.Add(cards);
        content.Controls.Add(checklistTitle);
        content.Controls.Add(checklist);
        content.Controls.Add(environment);
        return content;
    }

    private Panel CreateStatCard(string caption, string fallbackValue, string source, Color accent, Label valueLabel)
    {
        var card = new Panel
        {
            Size = new Size(258, 104),
            BackColor = Color.White,
            Margin = new Padding(0, 0, 18, 0),
            Padding = new Padding(16)
        };
        card.Paint += (_, e) =>
        {
            using var pen = new Pen(Color.FromArgb(222, 229, 239));
            e.Graphics.DrawRectangle(pen, 0, 0, card.Width - 1, card.Height - 1);
            using var brush = new SolidBrush(accent);
            e.Graphics.FillRectangle(brush, 0, 0, 5, card.Height);
        };

        valueLabel.Text = fallbackValue;
        valueLabel.ForeColor = accent;
        valueLabel.Font = new Font("Segoe UI", 25F, FontStyle.Bold);
        valueLabel.AutoSize = true;
        valueLabel.Location = new Point(18, 18);
        valueLabel.BackColor = Color.Transparent;

        var captionLabel = new Label
        {
            Text = caption,
            ForeColor = Navy,
            Font = new Font("Segoe UI", 9F, FontStyle.Bold),
            AutoSize = true,
            Location = new Point(21, 64),
            BackColor = Color.Transparent
        };
        var sourceLabel = new Label
        {
            Text = source,
            ForeColor = Muted,
            Font = new Font("Consolas", 7.5F),
            AutoSize = true,
            Location = new Point(21, 84),
            BackColor = Color.Transparent
        };

        card.Controls.Add(valueLabel);
        card.Controls.Add(captionLabel);
        card.Controls.Add(sourceLabel);
        return card;
    }

    private Label CreateCheckChip(string text)
    {
        return new Label
        {
            Text = "✓  " + text,
            ForeColor = Color.FromArgb(48, 92, 70),
            BackColor = Color.FromArgb(233, 246, 239),
            Font = new Font("Segoe UI", 8.5F),
            AutoSize = false,
            Size = new Size(190, 30),
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(8, 0, 0, 0),
            Margin = new Padding(0, 0, 8, 8)
        };
    }

    private StatusStrip BuildStatusBar()
    {
        var status = new StatusStrip
        {
            BackColor = Color.White,
            SizingGrip = false,
            Font = new Font("Segoe UI", 8.5F)
        };
        _lblStatus.Text = "Sẵn sàng";
        _lblStatus.Spring = true;
        _lblStatus.TextAlign = ContentAlignment.MiddleLeft;

        var engine = new ToolStripStatusLabel("Report Engine Ready");
        var student = new ToolStripStatusLabel("24003351 – Nguyễn Quang Dũng");
        status.Items.Add(_lblStatus);
        status.Items.Add(engine);
        status.Items.Add(new ToolStripSeparator());
        status.Items.Add(student);
        return status;
    }

    private MenuStrip BuildMenu()
    {
        var menu = new MenuStrip { BackColor = Color.White, Font = new Font("Segoe UI", 9F) };

        var system = new ToolStripMenuItem("Hệ thống");
        system.DropDownItems.Add(new ToolStripMenuItem("Làm mới số liệu", null, (_, _) => LoadSummary()) { ShortcutKeys = Keys.F5 });
        system.DropDownItems.Add(new ToolStripSeparator());
        system.DropDownItems.Add(new ToolStripMenuItem("Thoát", null, (_, _) => Close()));

        var reports = new ToolStripMenuItem("Báo cáo");
        reports.DropDownItems.Add(new ToolStripMenuItem("Danh sách Sinh viên", null, (_, _) => OpenReport(() => new frmBaoCaoSinhVien())));
        reports.DropDownItems.Add(new ToolStripMenuItem("Danh sách Khoa", null, (_, _) => OpenReport(() => new frmBaoCaoKhoa())));
        reports.DropDownItems.Add(new ToolStripMenuItem("Danh sách Học phần", null, (_, _) => OpenReport(() => new frmBaoCaoHocPhan())));
        reports.DropDownItems.Add(new ToolStripSeparator());
        reports.DropDownItems.Add(new ToolStripMenuItem("Đóng tất cả báo cáo", null, (_, _) => CloseAllReports()));

        var help = new ToolStripMenuItem("Trợ giúp");
        help.DropDownItems.Add(new ToolStripMenuItem("Kiểm tra kết nối CSDL", null, (_, _) => CheckConnection()));
        help.DropDownItems.Add(new ToolStripMenuItem("Mở thư mục Reports", null, (_, _) => OpenReportsFolder()));
        help.DropDownItems.Add(new ToolStripSeparator());
        help.DropDownItems.Add(new ToolStripMenuItem("Giới thiệu Lab 13", null, (_, _) => ShowAbout()));

        menu.Items.Add(system);
        menu.Items.Add(reports);
        menu.Items.Add(help);
        return menu;
    }

    private void LoadSummary()
    {
        try
        {
            var students = _service.GetStudentReport();
            var faculties = _service.GetFacultyReport();
            var courses = _service.GetCourseReport();

            _lblStudentCount.Text = students.Rows.Count.ToString();
            _lblFacultyCount.Text = faculties.Rows.Count.ToString();
            _lblCourseCount.Text = courses.Rows.Count.ToString();
            _lblDbStatus.Text = $"SQL Server: đã kết nối  •  QLSinhVien  •  {students.Rows.Count} sinh viên, {faculties.Rows.Count} khoa, {courses.Rows.Count} học phần";
            _lblDbStatus.ForeColor = Teal;
            _lblStatus.Text = $"Đã nạp dữ liệu lúc {DateTime.Now:HH:mm:ss}";
        }
        catch (Exception ex)
        {
            _lblDbStatus.Text = "SQL Server: chưa kết nối được – " + ex.Message;
            _lblDbStatus.ForeColor = Color.Firebrick;
            _lblStatus.Text = "Lỗi kết nối cơ sở dữ liệu";
        }
    }

    private void OpenReport<T>(Func<T> factory) where T : Form
    {
        if (_openReports.TryGetValue(typeof(T), out var existing) && !existing.IsDisposed)
        {
            if (existing.WindowState == FormWindowState.Minimized)
            {
                existing.WindowState = FormWindowState.Normal;
            }
            existing.Activate();
            existing.BringToFront();
            _lblStatus.Text = "Báo cáo đang mở – đã chuyển sang cửa sổ hiện có.";
            return;
        }

        var form = factory();
        _openReports[typeof(T)] = form;
        form.FormClosed += (_, _) =>
        {
            _openReports.Remove(typeof(T));
            form.Dispose();
            _lblStatus.Text = "Đã đóng báo cáo và giải phóng tài nguyên.";
        };
        form.Show(this);
        _lblStatus.Text = "Đã mở báo cáo.";
    }

    private void CloseAllReports()
    {
        foreach (var form in new List<Form>(_openReports.Values))
        {
            if (!form.IsDisposed) form.Close();
        }
        _openReports.Clear();
    }

    private void CheckConnection()
    {
        try
        {
            var server = _service.GetServerInfo();
            var students = _service.GetStudentReport();

            MessageBox.Show(
                "Kết nối cơ sở dữ liệu thành công!\n\n" +
                "Cơ sở dữ liệu: QLSinhVien\n" +
                $"Số sinh viên: {students.Rows.Count}\n" +
                $"Report engine: {GetReportEngineDescription()}\n\n" +
                "Phiên bản SQL Server:\n" + server,
                "Kiểm tra kết nối",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Không thể kết nối cơ sở dữ liệu.\n\n" + ex.Message +
                "\n\nKiểm tra service SQL Server (SQLEXPRESS) và chuỗi kết nối trong App.config.",
                "Lỗi kết nối",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }

    private void OpenReportsFolder()
    {
        var folder = System.IO.Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "Reports");
        folder = System.IO.Path.GetFullPath(folder);
        if (!System.IO.Directory.Exists(folder))
        {
            folder = AppContext.BaseDirectory;
        }
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
        {
            FileName = folder,
            UseShellExecute = true
        });
    }

    private void ShowAbout()
    {
        MessageBox.Show(
            "LAB 13 – TẠO BÁO CÁO CƠ BẢN BẰNG CRYSTAL REPORT\n\n" +
            "Sinh viên: Nguyễn Quang Dũng\n" +
            "MSSV: 24003351\n" +
            "Học phần: Lập trình .NET (IT3212)\n\n" +
            "Chức năng:\n" +
            "• 3 mẫu báo cáo: Sinh viên, Khoa, Học phần\n" +
            "• Xem trước A4, thiết kế section, in, xuất PDF/HTML\n" +
            "• Kiến trúc 3 lớp DAL – BUS – GUI\n\n" +
            $"Report engine: {GetReportEngineDescription()}",
            "Giới thiệu Lab 13",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information);
    }

    private static string GetReportEngineDescription()
    {
        try
        {
            var assembly = Assembly.Load("CrystalDecisions.CrystalReports.Engine");
            return $"SAP Crystal Reports {assembly.GetName().Version}";
        }
        catch
        {
            return "Report Engine nội bộ tương thích (chưa cài SAP Crystal Reports runtime)";
        }
    }
}
