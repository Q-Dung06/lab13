using System.Data;
using System.Drawing;
using Lab13.BUS;

namespace Lab13_CrystalReport;

public sealed class frmBaoCaoSinhVien : ReportFormBase
{
    protected override string ReportTitle => "BÁO CÁO DANH SÁCH SINH VIÊN";
    protected override string ReportCode => "CR-RPT-SV-01";

    public frmBaoCaoSinhVien()
        : base("Bài 1–5 | Báo cáo Danh sách Sinh viên – CrystalReportViewer", new Size(1080, 820))
    {
    }

    protected override DataTable LoadReportData() => Service.GetStudentReport();
}
