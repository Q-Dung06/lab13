using System.Data;
using System.Drawing;
using Lab13.BUS;

namespace Lab13_CrystalReport;

public sealed class frmBaoCaoKhoa : ReportFormBase
{
    protected override string ReportTitle => "BÁO CÁO DANH SÁCH KHOA VÀ SỐ LƯỢNG SINH VIÊN";
    protected override string ReportCode => "CR-RPT-KHOA-02";

    public frmBaoCaoKhoa()
        : base("Bài 6 | Báo cáo Danh sách Khoa – Số lượng sinh viên", new Size(1080, 760))
    {
    }

    protected override DataTable LoadReportData() => Service.GetFacultyReport();
}
