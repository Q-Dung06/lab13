using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Lab13.BUS;

namespace Lab13_CrystalReport;

/// <summary>
/// Form nền dùng chung cho 3 báo cáo. Mỗi báo cáo chỉ cần khai báo tiêu đề,
/// mã báo cáo và hàm lấy dữ liệu; phần viewer, toolbar và xử lý lỗi dùng chung.
/// </summary>
public abstract class ReportFormBase : Form
{
    protected readonly BaoCaoService Service = new();
    protected readonly ReportViewerPanel Viewer = new();

    protected abstract string ReportTitle { get; }
    protected abstract string ReportCode { get; }
    protected abstract DataTable LoadReportData();

    public ReportViewerPanel ReportViewer => Viewer;

    protected ReportFormBase(string windowTitle, Size size)
    {
        Text = windowTitle;
        Size = size;
        MinimumSize = new Size(900, 650);
        StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 9F);
        BackColor = Color.FromArgb(235, 240, 248);

        Viewer.Dock = DockStyle.Fill;
        Controls.Add(Viewer);

        Load += OnReportLoad;
    }

    private void OnReportLoad(object? sender, EventArgs e)
    {
        try
        {
            UseWaitCursor = true;
            var data = LoadReportData();
            Viewer.ReportTitle = ReportTitle;
            Viewer.ReportCode = ReportCode;
            Viewer.DataSource = data;
            Text = $"{ReportTitle}  |  {data.Rows.Count} dòng dữ liệu";
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                $"Không thể nạp dữ liệu báo cáo.\n\n{ex.Message}\n\n" +
                "Kiểm tra SQL Server Express và script Database/01_Lab13_Views_And_Data.sql.",
                "Lỗi nạp báo cáo",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
        finally
        {
            UseWaitCursor = false;
        }
    }

    public void ExportPdf(string targetPath) => Viewer.ExportToPdf(targetPath);

    public void ExportHtml(string targetPath) => Viewer.ExportToHtml(targetPath);
}
