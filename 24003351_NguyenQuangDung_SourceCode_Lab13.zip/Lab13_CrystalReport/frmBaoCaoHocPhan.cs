using System.Data;
using System.Drawing;
using Lab13.BUS;

namespace Lab13_CrystalReport;

public sealed class frmBaoCaoHocPhan : ReportFormBase
{
    protected override string ReportTitle => "BÁO CÁO DANH SÁCH HỌC PHẦN (SẮP XẾP THEO TÊN)";
    protected override string ReportCode => "CR-RPT-HP-03";

    public frmBaoCaoHocPhan()
        : base("Bài 8 | Báo cáo Danh sách Học phần – Sắp xếp theo tên", new Size(1080, 760))
    {
    }

    protected override DataTable LoadReportData() => Service.GetCourseReport();
}
