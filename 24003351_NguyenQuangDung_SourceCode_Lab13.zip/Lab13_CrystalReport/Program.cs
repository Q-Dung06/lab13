using System;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using Lab13.BUS;

namespace Lab13_CrystalReport;

internal static class Program
{
    [STAThread]
    private static void Main(string[] args)
    {
        ApplicationConfiguration.Initialize();

        if (args.Length > 0)
        {
            switch (args[0].ToLowerInvariant())
            {
                case "--test":
                    RunTests();
                    return;
                case "--capture":
                    RunCapture(GetArgument(args, 1, "Screenshots"));
                    return;
                case "--export":
                    RunExport(GetArgument(args, 1, "Reports"));
                    return;
            }
        }

        Application.Run(new MainForm());
    }

    private static string GetArgument(string[] args, int index, string fallback)
    {
        return args.Length > index ? args[index] : fallback;
    }

    private static string ResolveFolder(string folder)
    {
        if (Path.IsPathRooted(folder)) return Path.GetFullPath(folder);
        return Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", folder));
    }

    private static void Log(string folder, string message)
    {
        Console.WriteLine(message);
        try
        {
            Directory.CreateDirectory(folder);
            File.AppendAllText(Path.Combine(folder, "run.log"), message + Environment.NewLine);
        }
        catch
        {
            // Bỏ qua lỗi ghi log, không ảnh hưởng chức năng chính.
        }
    }

    private static void RunTests()
    {
        try
        {
            var service = new BaoCaoService();

            var students = service.GetStudentReport();
            var faculties = service.GetFacultyReport();
            var courses = service.GetCourseReport();
            var server = service.GetServerInfo();

            Console.WriteLine("=== LAB 13 SMOKE TEST ===");
            Console.WriteLine($"SQL Server: {server.Split('\n')[0].Trim()}");
            Console.WriteLine($"Sinh viên: {students.Rows.Count} dòng, {students.Columns.Count} cột");
            Console.WriteLine($"Khoa: {faculties.Rows.Count} dòng, {faculties.Columns.Count} cột");
            Console.WriteLine($"Học phần: {courses.Rows.Count} dòng, {courses.Columns.Count} cột");

            Require(students.Rows.Count >= 20, "Cần tối thiểu 20 sinh viên theo yêu cầu Lab 13.");
            Require(students.Columns.Contains("MaSV"), "Thiếu cột MaSV trong báo cáo sinh viên.");
            Require(students.Columns.Contains("TenKhoa"), "Thiếu cột TenKhoa trong báo cáo sinh viên.");
            Require(faculties.Columns.Contains("SoLuongSinhVien"), "Thiếu cột SoLuongSinhVien trong báo cáo khoa.");
            Require(courses.Columns.Contains("SoTinChi"), "Thiếu cột SoTinChi trong báo cáo học phần.");

            var courseNames = courses.Rows.Cast<DataRow>().Select(r => r["TenHP"]?.ToString() ?? string.Empty).ToList();
            var sorted = courseNames.OrderBy(n => n, StringComparer.CurrentCulture).ToList();
            Require(courseNames.SequenceEqual(sorted), "Báo cáo học phần chưa sắp xếp theo tên.");

            Console.WriteLine("TESTS OK");
            Environment.ExitCode = 0;
        }
        catch (Exception ex)
        {
            Console.WriteLine("TEST ERROR: " + ex);
            Environment.ExitCode = 1;
        }
    }

    private static void Require(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }

    private static void RunExport(string folder)
    {
        var dir = ResolveFolder(folder);
        Directory.CreateDirectory(dir);
        Log(dir, "=== LAB 13 EXPORT ===");
        try
        {
            var service = new BaoCaoService();
            Export(service.GetStudentReport(), "BÁO CÁO DANH SÁCH SINH VIÊN", "CR-RPT-SV-01", Path.Combine(dir, "DanhSachSinhVien.pdf"), dir);
            Export(service.GetFacultyReport(), "BÁO CÁO DANH SÁCH KHOA VÀ SỐ LƯỢNG SINH VIÊN", "CR-RPT-KHOA-02", Path.Combine(dir, "DanhSachKhoa.pdf"), dir);
            Export(service.GetCourseReport(), "BÁO CÁO DANH SÁCH HỌC PHẦN (SẮP XẾP THEO TÊN)", "CR-RPT-HP-03", Path.Combine(dir, "DanhSachHocPhan.pdf"), dir);
            Log(dir, "EXPORT OK");
            Environment.ExitCode = 0;
        }
        catch (Exception ex)
        {
            Log(dir, "EXPORT ERROR: " + ex);
            Environment.ExitCode = 1;
        }
    }

    private static void Export(DataTable data, string title, string code, string pdfPath, string logFolder)
    {
        using var viewer = new ReportViewerPanel
        {
            ReportTitle = title,
            ReportCode = code,
            DataSource = data
        };
        viewer.ExportToPdf(pdfPath);
        var info = new FileInfo(pdfPath);
        Log(logFolder, $"Đã xuất {Path.GetFileName(pdfPath)} ({info.Length:N0} bytes, {data.Rows.Count} dòng)");
    }

    private static void RunCapture(string folder)
    {
        var dir = ResolveFolder(folder);
        Directory.CreateDirectory(dir);
        Log(dir, "=== LAB 13 CAPTURE ===");

        using var main = new MainForm();
        main.Show();
        Application.DoEvents();
        Thread.Sleep(900);
        CaptureControl(main, Path.Combine(dir, "01_TongQuan_MainForm.png"), dir);

        CaptureReport(new frmBaoCaoSinhVien(), "02_BaoCao_SinhVien", dir, captureDesign: true);
        CaptureReport(new frmBaoCaoKhoa(), "03_BaoCao_Khoa", dir, captureDesign: false);
        CaptureReport(new frmBaoCaoHocPhan(), "04_BaoCao_HocPhan", dir, captureDesign: false);

        Log(dir, "CAPTURE OK");
        Environment.ExitCode = 0;
    }

    private static void CaptureReport(Form form, string name, string dir, bool captureDesign)
    {
        using (form)
        {
            form.StartPosition = FormStartPosition.Manual;
            form.Location = new Point(40, 40);
            form.Show();
            Application.DoEvents();
            Thread.Sleep(900);

            CaptureControl(form, Path.Combine(dir, name + ".png"), dir);

            if (form is ReportFormBase reportForm)
            {
                using (var page = reportForm.ReportViewer.RenderPageBitmap())
                {
                    page.Save(Path.Combine(dir, name + "_ToanTrang.png"), ImageFormat.Png);
                    Log(dir, $"Đã chụp toàn trang: {name}_ToanTrang.png");
                }

                if (captureDesign)
                {
                    reportForm.ReportViewer.ShowReportDesign = true;
                    Application.DoEvents();
                    Thread.Sleep(250);
                    using var design = reportForm.ReportViewer.RenderPageBitmap();
                    design.Save(Path.Combine(dir, "05_ThietKe_Report_SinhVien.png"), ImageFormat.Png);
                    Log(dir, "Đã chụp thiết kế report: 05_ThietKe_Report_SinhVien.png");
                    reportForm.ReportViewer.ShowReportDesign = false;
                }
            }

            form.Close();
        }
    }

    private static void CaptureControl(Control control, string path, string logFolder)
    {
        using var bmp = new Bitmap(control.Width, control.Height);
        control.DrawToBitmap(bmp, new Rectangle(0, 0, control.Width, control.Height));
        bmp.Save(path, ImageFormat.Png);
        Log(logFolder, $"Đã chụp: {Path.GetFileName(path)} ({control.Width}x{control.Height})");
    }
}
