using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Lab13_CrystalReport;

public sealed class ReportViewerPanel : UserControl
{
    private DataTable? _dataSource;
    private string _reportTitle = "BÁO CÁO";
    private string _reportCode = "CR-RPT-LAB13";
    private bool _showReportDesign;
    private readonly ToolStrip _toolbar = new();
    private readonly ToolStripButton _btnPrint = new();
    private readonly ToolStripButton _btnExportPdf = new();
    private readonly ToolStripButton _btnExportHtml = new();
    private readonly ToolStripButton _btnZoomIn = new();
    private readonly ToolStripButton _btnZoomOut = new();
    private readonly ToolStripButton _btnDesign = new();
    private readonly ToolStripButton _btnRefresh = new();
    private readonly ToolStripLabel _lblPageInfo = new();
    private readonly Panel _previewContainer = new();
    private readonly Panel _paperPage = new();
    private float _zoomFactor = 1.0f;

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public DataTable? DataSource
    {
        get => _dataSource;
        set
        {
            _dataSource = value;
            RenderReportPage();
        }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public string ReportTitle
    {
        get => _reportTitle;
        set
        {
            _reportTitle = value;
            RenderReportPage();
        }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public string ReportCode
    {
        get => _reportCode;
        set
        {
            _reportCode = value;
            RenderReportPage();
        }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public bool ShowReportDesign
    {
        get => _showReportDesign;
        set
        {
            _showReportDesign = value;
            _btnDesign.Checked = value;
            _btnDesign.Text = value ? " Xem báo cáo" : " Thiết kế";
            RenderReportPage();
        }
    }

    public ReportViewerPanel()
    {
        Dock = DockStyle.Fill;
        BackColor = Color.FromArgb(235, 240, 248);
        BuildToolbar();

        _previewContainer.Dock = DockStyle.Fill;
        _previewContainer.AutoScroll = true;
        _previewContainer.BackColor = Color.FromArgb(100, 110, 125);
        _previewContainer.Padding = new Padding(25);

        _paperPage.BackColor = Color.White;
        _paperPage.Size = new Size(820, 1160);
        _paperPage.Paint += PaperPage_Paint;

        _previewContainer.Controls.Add(_paperPage);
        Controls.Add(_previewContainer);
        Controls.Add(_toolbar);

        CenterPaper();
        _previewContainer.Resize += (_, _) => CenterPaper();
    }

    private void CenterPaper()
    {
        int x = Math.Max(25, (_previewContainer.ClientSize.Width - _paperPage.Width) / 2);
        _paperPage.Location = new Point(x, 25);
    }

    private void BuildToolbar()
    {
        _toolbar.GripStyle = ToolStripGripStyle.Hidden;
        _toolbar.BackColor = Color.FromArgb(245, 248, 252);
        _toolbar.Padding = new Padding(6, 4, 6, 4);

        _btnPrint.Text = " In báo cáo";
        _btnPrint.Click += (_, _) => PrintReport();
        _toolbar.Items.Add(_btnPrint);

        _btnExportPdf.Text = " Xuất PDF (Bài 5)";
        _btnExportPdf.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        _btnExportPdf.ForeColor = Color.FromArgb(16, 129, 102);
        _btnExportPdf.Click += (_, _) => ExportToPdf();
        _toolbar.Items.Add(_btnExportPdf);

        _btnExportHtml.Text = " Xuất HTML";
        _btnExportHtml.Click += (_, _) => ExportToHtml();
        _toolbar.Items.Add(_btnExportHtml);

        _toolbar.Items.Add(new ToolStripSeparator());

        _btnZoomIn.Text = "Phóng to (+)";
        _btnZoomIn.Click += (_, _) => { _zoomFactor = Math.Min(1.6f, _zoomFactor + 0.15f); ApplyZoom(); };
        _toolbar.Items.Add(_btnZoomIn);

        _btnZoomOut.Text = "Thu nhỏ (-)";
        _btnZoomOut.Click += (_, _) => { _zoomFactor = Math.Max(0.6f, _zoomFactor - 0.15f); ApplyZoom(); };
        _toolbar.Items.Add(_btnZoomOut);

        _btnDesign.Text = " Thiết kế";
        _btnDesign.CheckOnClick = true;
        _btnDesign.CheckedChanged += (_, _) =>
        {
            _showReportDesign = _btnDesign.Checked;
            _btnDesign.Text = _showReportDesign ? " Xem báo cáo" : " Thiết kế";
            RenderReportPage();
        };
        _toolbar.Items.Add(_btnDesign);

        _btnRefresh.Text = "Làm mới";
        _btnRefresh.Click += (_, _) => RenderReportPage();
        _toolbar.Items.Add(_btnRefresh);

        _toolbar.Items.Add(new ToolStripSeparator());
        _lblPageInfo.Text = "Trang 1 / 1  |  A4 Portrait  |  Report Engine Ready";
        _toolbar.Items.Add(_lblPageInfo);
    }

    private void ApplyZoom()
    {
        _paperPage.Size = new Size((int)(820 * _zoomFactor), (int)(1160 * _zoomFactor));
        CenterPaper();
        _paperPage.Invalidate();
    }

    public void RenderReportPage()
    {
        int rows = _dataSource?.Rows.Count ?? 0;
        _lblPageInfo.Text = $"Trang 1 / 1  |  {rows} dòng  |  A4 Portrait  |  {_reportCode}";
        _paperPage.Invalidate();
    }

    private void PaperPage_Paint(object? sender, PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

        // Tỉ lệ scale
        g.ScaleTransform(_zoomFactor, _zoomFactor);

        if (_showReportDesign)
        {
            DrawDesignSurface(g);
            return;
        }

        // Header: Logo & Tên trường
        using var fontSchool = new Font("Segoe UI", 10.5F, FontStyle.Bold);
        using var fontSub = new Font("Segoe UI", 8.5F, FontStyle.Regular);
        using var fontTitle = new Font("Segoe UI", 16F, FontStyle.Bold);
        using var fontHeader = new Font("Segoe UI", 9F, FontStyle.Bold);
        using var fontBody = new Font("Segoe UI", 8.5F, FontStyle.Regular);
        using var fontFooter = new Font("Segoe UI", 8F, FontStyle.Italic);

        // Huy hiệu trường
        g.FillEllipse(new SolidBrush(Color.FromArgb(25, 63, 110)), 40, 35, 46, 46);
        using var logoFont = new Font("Segoe UI", 14F, FontStyle.Bold);
        g.DrawString("E", logoFont, Brushes.White, 52, 43);

        g.DrawString("TRƯỜNG ĐẠI HỌC CÔNG NGHỆ ĐÔNG Á", fontSchool, new SolidBrush(Color.FromArgb(25, 63, 110)), 96, 38);
        g.DrawString("KHOA CÔNG NGHỆ THÔNG TIN – BỘ MÔN CÔNG NGHỆ PHẦN MỀM", fontSub, Brushes.DimGray, 96, 58);
        g.DrawString("HỌC PHẦN: LẬP TRÌNH .NET (IT3212)", fontSub, Brushes.DimGray, 96, 74);

        g.DrawLine(new Pen(Color.FromArgb(25, 63, 110), 2), 40, 96, 780, 96);
        g.DrawLine(new Pen(Color.FromArgb(16, 129, 102), 1), 40, 99, 780, 99);

        // Tiêu đề báo cáo
        var sfCenter = new StringFormat { Alignment = StringAlignment.Center };
        g.DrawString(_reportTitle, fontTitle, new SolidBrush(Color.FromArgb(25, 63, 110)), 410, 118, sfCenter);

        // Thông tin ngày lập & người lập
        string dateStr = $"Ngày lập báo cáo: {DateTime.Now:dd/MM/yyyy HH:mm}   |   Người lập: Nguyễn Quang Dũng (MSSV: 24003351)";
        g.DrawString(dateStr, fontSub, Brushes.DimGray, 410, 150, sfCenter);

        int startY = 180;

        if (_dataSource == null || _dataSource.Rows.Count == 0)
        {
            g.DrawString("Không có dữ liệu để hiển thị trên báo cáo.", fontBody, Brushes.Red, 410, 240, sfCenter);
            return;
        }

        // Vẽ bảng dữ liệu theo từng loại báo cáo
        if (_dataSource.TableName == "SinhVienReport")
        {
            DrawStudentReportTable(g, fontHeader, fontBody, startY);
        }
        else if (_dataSource.TableName == "KhoaReport")
        {
            DrawFacultyReportTable(g, fontHeader, fontBody, startY);
        }
        else if (_dataSource.TableName == "HocPhanReport")
        {
            DrawCourseReportTable(g, fontHeader, fontBody, startY);
        }
        else
        {
            DrawGenericTable(g, fontHeader, fontBody, startY);
        }

        // Footer: Số trang & xác nhận
        g.DrawLine(Pens.LightGray, 40, 1100, 780, 1100);
        g.DrawString($"{_reportCode} – SAP Crystal Reports for Visual Studio Runtime Simulation – Lab 13", fontFooter, Brushes.Gray, 40, 1108);
        g.DrawString("Trang 1 / 1", fontFooter, Brushes.Gray, 720, 1108);
    }

    private void DrawDesignSurface(Graphics g)
    {
        using var bandFont = new Font("Segoe UI", 7.5F, FontStyle.Bold);
        using var bandValueFont = new Font("Segoe UI", 7F, FontStyle.Regular);
        using var fieldFont = new Font("Consolas", 7.5F);
        using var titleFont = new Font("Segoe UI", 13F, FontStyle.Bold);
        using var headerFont = new Font("Segoe UI", 8F, FontStyle.Bold);

        g.FillRectangle(new SolidBrush(Color.FromArgb(248, 249, 251)), 0, 0, 820, 1160);
        g.DrawRectangle(new Pen(Color.FromArgb(190, 198, 210)), 18, 18, 784, 1124);

        // Thước đo ngang
        using var rulerPen = new Pen(Color.FromArgb(205, 212, 222));
        for (int x = 40; x <= 780; x += 20)
        {
            int len = (x % 100 == 0) ? 9 : 5;
            g.DrawLine(rulerPen, x, 27, x, 27 + len);
            if (x % 100 == 0)
            {
                g.DrawString((x - 40).ToString(), bandValueFont, Brushes.Gray, x - 8, 14);
            }
        }

        var columns = GetDesignColumns();
        int totalWidth = 740;
        int x0 = 40;

        DrawBand(g, "Report Header", 40, 45, totalWidth, 92, Color.FromArgb(231, 239, 250), bandFont);
        g.DrawEllipse(new Pen(Color.FromArgb(25, 63, 110)), x0 + 8, 58, 30, 30);
        g.DrawString("E", titleFont, new SolidBrush(Color.FromArgb(25, 63, 110)), x0 + 13, 58);
        g.DrawString("TRƯỜNG ĐẠI HỌC CÔNG NGHỆ ĐÔNG Á", headerFont, new SolidBrush(Color.FromArgb(25, 63, 110)), x0 + 48, 57);
        g.DrawString("KHOA CÔNG NGHỆ THÔNG TIN – BỘ MÔN CÔNG NGHỆ PHẦN MỀM", bandValueFont, Brushes.DimGray, x0 + 48, 75);
        g.DrawString(_reportTitle, titleFont, new SolidBrush(Color.FromArgb(25, 63, 110)), x0, 100);
        g.DrawString("Ngày lập: {@NgayLap}   |   Người lập: {@NguoiLap}", bandValueFont, Brushes.DimGray, x0 + 380, 103);

        DrawBand(g, "Page Header", 40, 145, totalWidth, 34, Color.FromArgb(238, 246, 240), bandFont);
        int cursorX = x0;
        for (int i = 0; i < columns.Headers.Length; i++)
        {
            g.FillRectangle(new SolidBrush(Color.FromArgb(25, 65, 110)), cursorX, 153, columns.Widths[i], 20);
            g.DrawString(columns.Headers[i], headerFont, Brushes.White, cursorX + 3, 156);
            cursorX += columns.Widths[i];
        }

        DrawBand(g, "Details", 40, 187, totalWidth, 690, Color.White, bandFont);
        int rowY = 203;
        for (int r = 0; r < 6; r++)
        {
            cursorX = x0;
            for (int c = 0; c < columns.Headers.Length; c++)
            {
                var rect = new Rectangle(cursorX, rowY, columns.Widths[c], 28);
                g.DrawRectangle(new Pen(Color.FromArgb(210, 218, 230)), rect);
                var state = g.Save();
                g.SetClip(rect);
                g.DrawString(columns.Fields[c], fieldFont, new SolidBrush(Color.FromArgb(50, 90, 150)), cursorX + 3, rowY + 7);
                g.Restore(state);
                cursorX += columns.Widths[c];
            }
            rowY += 28;
        }
        g.DrawString("... (Details: lặp lại cho đến hết dữ liệu nguồn)", fieldFont, Brushes.Gray, x0 + 4, rowY + 8);

        DrawBand(g, "Report Footer", 40, 889, totalWidth, 100, Color.FromArgb(252, 245, 232), bandFont);
        g.DrawString("Tổng số: {Count(Rows)}   |   Cột tính tổng: {@TongSo}", fieldFont, Brushes.DimGray, x0 + 4, 910);
        g.DrawString("Ngày lập báo cáo: {CurrentDateTime}   |   Người lập: Nguyễn Quang Dũng (24003351)", fieldFont, Brushes.DimGray, x0 + 4, 932);
        g.DrawString("Chữ ký / xác nhận: ..............................................", fieldFont, Brushes.DimGray, x0 + 4, 954);

        DrawBand(g, "Page Footer", 40, 999, totalWidth, 55, Color.FromArgb(239, 242, 247), bandFont);
        g.DrawString($"{_reportCode} – Thiết kế báo cáo A4 Portrait", bandValueFont, Brushes.Gray, x0 + 4, 1015);
        using (var farFormat = new StringFormat { Alignment = StringAlignment.Far })
        {
            g.DrawString("Trang {PageNumber} / {TotalPageCount}", bandValueFont, Brushes.Gray,
                new RectangleF(x0, 1015, totalWidth - 12, 16), farFormat);
        }
        g.DrawString("Các section được đặt tên theo chuẩn Crystal Reports: Report Header / Page Header / Details / Report Footer / Page Footer.", bandValueFont, Brushes.Gray, x0 + 4, 1035);
    }

    private void DrawBand(Graphics g, string name, int x, int y, int width, int height, Color fill, Font font)
    {
        using var fillBrush = new SolidBrush(fill);
        using var borderPen = new Pen(Color.FromArgb(120, 150, 190)) { DashStyle = System.Drawing.Drawing2D.DashStyle.Dash };
        g.FillRectangle(fillBrush, x, y, width, height);
        g.DrawRectangle(borderPen, x, y, width, height);
        g.DrawString(name, font, new SolidBrush(Color.FromArgb(90, 110, 140)), x + 4, y + 2);
    }

    private (string[] Headers, string[] Fields, int[] Widths) GetDesignColumns()
    {
        return _dataSource?.TableName switch
        {
            "KhoaReport" => (
                ["STT", "Mã khoa", "Tên khoa", "Số lượng SV", "Điểm TB khoa"],
                ["{STT}", "{MaKhoa}", "{TenKhoa}", "{SoLuongSinhVien}", "{DiemTrungBinhKhoa}"],
                [60, 140, 280, 130, 130]),
            "HocPhanReport" => (
                ["STT", "Mã học phần", "Tên học phần", "Số tín chỉ", "Số SV đăng ký"],
                ["{STT}", "{MaHP}", "{TenHP}", "{SoTinChi}", "{SoSinhVienDangKy}"],
                [60, 140, 320, 100, 120]),
            _ => (
                ["STT", "Mã SV", "Họ và tên", "Ngày sinh", "Phái", "Khoa", "ĐTB", "Email"],
                ["{STT}", "{MaSV}", "{HoTen}", "{NgaySinh}", "{Phai}", "{Khoa}", "{DTB}", "{Email}"],
                [36, 62, 145, 80, 42, 155, 45, 175])
        };
    }

    private void DrawStudentReportTable(Graphics g, Font fontHeader, Font fontBody, int startY)
    {
        int[] colW = [36, 62, 145, 80, 42, 155, 45, 175];
        string[] headers = ["STT", "Mã SV", "Họ và tên", "Ngày sinh", "Phái", "Khoa", "ĐTB", "Email"];
        int totalW = 740;
        int x0 = 40;

        // Header Background
        var headerRect = new Rectangle(x0, startY, totalW, 26);
        g.FillRectangle(new SolidBrush(Color.FromArgb(25, 65, 110)), headerRect);
        int curX = x0;
        for (int i = 0; i < headers.Length; i++)
        {
            var cell = new Rectangle(curX, startY, colW[i], 26);
            DrawCellText(g, headers[i], fontHeader, Brushes.White, cell, i is 0 or 3 or 4 or 6 ? StringAlignment.Center : StringAlignment.Near);
            curX += colW[i];
        }

        int curY = startY + 26;
        int count = Math.Min(_dataSource!.Rows.Count, 30); // Vừa gọn 1 trang A4
        for (int i = 0; i < count; i++)
        {
            var row = _dataSource.Rows[i];
            var bg = (i % 2 == 1) ? new SolidBrush(Color.FromArgb(245, 248, 252)) : Brushes.White;
            g.FillRectangle(bg, x0, curY, totalW, 22);
            g.DrawRectangle(new Pen(Color.FromArgb(225, 230, 240)), x0, curY, totalW, 22);

            int cx = x0;
            var rowRect = new Rectangle(cx, curY, colW[0], 22);
            DrawCellText(g, (i + 1).ToString(), fontBody, Brushes.Black, rowRect, StringAlignment.Center);
            cx += colW[0];
            rowRect = new Rectangle(cx, curY, colW[1], 22);
            DrawCellText(g, row["MaSV"]?.ToString() ?? "", fontBody, Brushes.Black, rowRect);
            cx += colW[1];
            rowRect = new Rectangle(cx, curY, colW[2], 22);
            DrawCellText(g, row["HoTen"]?.ToString() ?? "", fontBody, Brushes.Black, rowRect);
            cx += colW[2];
            string ns = (row["NgaySinh"] is DateTime dt) ? dt.ToString("dd/MM/yyyy") : "";
            rowRect = new Rectangle(cx, curY, colW[3], 22);
            DrawCellText(g, ns, fontBody, Brushes.Black, rowRect, StringAlignment.Center);
            cx += colW[3];
            rowRect = new Rectangle(cx, curY, colW[4], 22);
            DrawCellText(g, row["GioiTinh"]?.ToString() ?? "", fontBody, Brushes.Black, rowRect, StringAlignment.Center);
            cx += colW[4];
            rowRect = new Rectangle(cx, curY, colW[5], 22);
            DrawCellText(g, row["TenKhoa"]?.ToString() ?? "", fontBody, Brushes.Black, rowRect);
            cx += colW[5];
            string dtb = (row["DiemTB"] != DBNull.Value) ? Convert.ToDecimal(row["DiemTB"]).ToString("N2") : "";
            rowRect = new Rectangle(cx, curY, colW[6], 22);
            DrawCellText(g, dtb, fontBody, Brushes.Black, rowRect, StringAlignment.Far);
            cx += colW[6];
            rowRect = new Rectangle(cx, curY, colW[7], 22);
            DrawCellText(g, row["Email"]?.ToString() ?? "", fontBody, Brushes.Black, rowRect);

            curY += 22;
        }

        // Summary row
        curY += 8;
        g.DrawString($"Tổng số sinh viên trong báo cáo: {_dataSource.Rows.Count} sinh viên", fontHeader, new SolidBrush(Color.FromArgb(25, 63, 110)), x0, curY);
    }

    private static void DrawCellText(Graphics g, string text, Font font, Brush brush, Rectangle bounds, StringAlignment alignment = StringAlignment.Near)
    {
        using var format = new StringFormat
        {
            Alignment = alignment,
            LineAlignment = StringAlignment.Center,
            FormatFlags = StringFormatFlags.NoWrap
        };
        var textRect = new Rectangle(bounds.X + 4, bounds.Y, Math.Max(1, bounds.Width - 7), bounds.Height);
        g.DrawString(text, font, brush, textRect, format);
    }

    private void DrawFacultyReportTable(Graphics g, Font fontHeader, Font fontBody, int startY)
    {
        int[] colW = [60, 140, 280, 130, 130];
        string[] headers = ["STT", "Mã khoa", "Tên khoa", "Số lượng SV", "Điểm TB khoa"];
        int totalW = 740;
        int x0 = 40;

        g.FillRectangle(new SolidBrush(Color.FromArgb(25, 65, 110)), x0, startY, totalW, 28);
        int curX = x0;
        for (int i = 0; i < headers.Length; i++)
        {
            DrawCellText(g, headers[i], fontHeader, Brushes.White, new Rectangle(curX, startY, colW[i], 28), i == 0 ? StringAlignment.Center : StringAlignment.Near);
            curX += colW[i];
        }

        int curY = startY + 28;
        for (int i = 0; i < _dataSource!.Rows.Count; i++)
        {
            var row = _dataSource.Rows[i];
            var bg = (i % 2 == 1) ? new SolidBrush(Color.FromArgb(245, 248, 252)) : Brushes.White;
            g.FillRectangle(bg, x0, curY, totalW, 26);
            g.DrawRectangle(new Pen(Color.FromArgb(225, 230, 240)), x0, curY, totalW, 26);

            int cx = x0;
            DrawCellText(g, (i + 1).ToString(), fontBody, Brushes.Black, new Rectangle(cx, curY, colW[0], 26), StringAlignment.Center);
            cx += colW[0];
            DrawCellText(g, row["MaKhoa"]?.ToString() ?? "", fontBody, Brushes.Black, new Rectangle(cx, curY, colW[1], 26));
            cx += colW[1];
            DrawCellText(g, row["TenKhoa"]?.ToString() ?? "", fontBody, Brushes.Black, new Rectangle(cx, curY, colW[2], 26));
            cx += colW[2];
            DrawCellText(g, row["SoLuongSinhVien"]?.ToString() ?? "0", fontBody, Brushes.Black, new Rectangle(cx, curY, colW[3], 26), StringAlignment.Center);
            cx += colW[3];
            string dtb = (row["DiemTrungBinhKhoa"] != DBNull.Value) ? Convert.ToDecimal(row["DiemTrungBinhKhoa"]).ToString("N2") : "0.00";
            DrawCellText(g, dtb, fontBody, Brushes.Black, new Rectangle(cx, curY, colW[4], 26), StringAlignment.Far);

            curY += 26;
        }

        curY += 10;
        g.DrawString($"Tổng số khoa đào tạo: {_dataSource.Rows.Count} khoa", fontHeader, new SolidBrush(Color.FromArgb(25, 63, 110)), x0, curY);
    }

    private void DrawCourseReportTable(Graphics g, Font fontHeader, Font fontBody, int startY)
    {
        int[] colW = [60, 140, 320, 100, 120];
        string[] headers = ["STT", "Mã học phần", "Tên học phần (Sắp xếp theo tên)", "Số tín chỉ", "Số SV đăng ký"];
        int totalW = 740;
        int x0 = 40;

        g.FillRectangle(new SolidBrush(Color.FromArgb(25, 65, 110)), x0, startY, totalW, 28);
        int curX = x0;
        for (int i = 0; i < headers.Length; i++)
        {
            DrawCellText(g, headers[i], fontHeader, Brushes.White, new Rectangle(curX, startY, colW[i], 28), i == 0 ? StringAlignment.Center : StringAlignment.Near);
            curX += colW[i];
        }

        int curY = startY + 28;
        for (int i = 0; i < _dataSource!.Rows.Count; i++)
        {
            var row = _dataSource.Rows[i];
            var bg = (i % 2 == 1) ? new SolidBrush(Color.FromArgb(245, 248, 252)) : Brushes.White;
            g.FillRectangle(bg, x0, curY, totalW, 26);
            g.DrawRectangle(new Pen(Color.FromArgb(225, 230, 240)), x0, curY, totalW, 26);

            int cx = x0;
            DrawCellText(g, (i + 1).ToString(), fontBody, Brushes.Black, new Rectangle(cx, curY, colW[0], 26), StringAlignment.Center);
            cx += colW[0];
            DrawCellText(g, row["MaHP"]?.ToString() ?? "", fontBody, Brushes.Black, new Rectangle(cx, curY, colW[1], 26));
            cx += colW[1];
            DrawCellText(g, row["TenHP"]?.ToString() ?? "", fontBody, Brushes.Black, new Rectangle(cx, curY, colW[2], 26));
            cx += colW[2];
            DrawCellText(g, row["SoTinChi"]?.ToString() ?? "0", fontBody, Brushes.Black, new Rectangle(cx, curY, colW[3], 26), StringAlignment.Center);
            cx += colW[3];
            DrawCellText(g, row["SoSinhVienDangKy"]?.ToString() ?? "0", fontBody, Brushes.Black, new Rectangle(cx, curY, colW[4], 26), StringAlignment.Center);

            curY += 26;
        }

        curY += 10;
        g.DrawString($"Tổng số học phần trong chương trình đào tạo: {_dataSource.Rows.Count} học phần", fontHeader, new SolidBrush(Color.FromArgb(25, 63, 110)), x0, curY);
    }

    private void DrawGenericTable(Graphics g, Font fontHeader, Font fontBody, int startY)
    {
        if (_dataSource == null || _dataSource.Columns.Count == 0) return;
        int colCount = _dataSource.Columns.Count;
        int colWidth = 740 / colCount;
        int x0 = 40;

        g.FillRectangle(new SolidBrush(Color.FromArgb(25, 65, 110)), x0, startY, 740, 26);
        for (int c = 0; c < colCount; c++)
        {
            g.DrawString(_dataSource.Columns[c].ColumnName, fontHeader, Brushes.White, x0 + c * colWidth + 4, startY + 5);
        }

        int curY = startY + 26;
        for (int r = 0; r < Math.Min(_dataSource.Rows.Count, 25); r++)
        {
            var row = _dataSource.Rows[r];
            for (int c = 0; c < colCount; c++)
            {
                g.DrawString(row[c]?.ToString() ?? "", fontBody, Brushes.Black, x0 + c * colWidth + 4, curY + 3);
            }
            curY += 22;
        }
    }

    public void ExportToPdf(string? targetFilePath = null)
    {
        string filePath = targetFilePath ?? "";
        if (string.IsNullOrEmpty(filePath))
        {
            using var dlg = new SaveFileDialog
            {
                Filter = "PDF file (*.pdf)|*.pdf",
                FileName = $"{_reportTitle.Replace(" ", "_")}.pdf"
            };
            if (dlg.ShowDialog() != DialogResult.OK) return;
            filePath = dlg.FileName;
        }

        try
        {
            // Xuất báo cáo sắc nét ra bitmap rồi đóng gói thành PDF chuẩn A4
            var directory = Path.GetDirectoryName(filePath);
            if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);

            float oldZoom = _zoomFactor;
            bool oldDesign = _showReportDesign;
            _zoomFactor = 1.0f;
            _showReportDesign = false;

            try
            {
                using var bmp = new Bitmap(820, 1160);
                bmp.SetResolution(96, 96);
                using (var g = Graphics.FromImage(bmp))
                {
                    g.Clear(Color.White);
                    PaperPage_Paint(this, new PaintEventArgs(g, new Rectangle(0, 0, 820, 1160)));
                }

                // Ghi file PDF chuẩn thông qua Image/Canvas PDF Generator
                SaveBitmapAsPdf(bmp, filePath, _reportTitle);
            }
            finally
            {
                _zoomFactor = oldZoom;
                _showReportDesign = oldDesign;
            }

            if (string.IsNullOrEmpty(targetFilePath))
            {
                MessageBox.Show($"Đã xuất báo cáo '{_reportTitle}' sang PDF thành công!\nĐường dẫn: {filePath}", "Xuất PDF (Bài 5)", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Lỗi khi xuất PDF: {ex.Message}", "Lỗi xuất báo cáo", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    public Bitmap RenderPageBitmap()
    {
        var bmp = new Bitmap(820, 1160);
        bmp.SetResolution(96, 96);
        float oldZoom = _zoomFactor;
        _zoomFactor = 1.0f;
        try
        {
            using var g = Graphics.FromImage(bmp);
            g.Clear(Color.White);
            PaperPage_Paint(this, new PaintEventArgs(g, new Rectangle(0, 0, 820, 1160)));
        }
        finally
        {
            _zoomFactor = oldZoom;
        }
        return bmp;
    }

    public void ExportToHtml(string? targetFilePath = null)
    {
        string filePath = targetFilePath ?? "";
        if (string.IsNullOrEmpty(filePath))
        {
            using var dlg = new SaveFileDialog
            {
                Filter = "HTML file (*.html)|*.html",
                FileName = $"{_reportTitle.Replace(" ", "_")}.html"
            };
            if (dlg.ShowDialog() != DialogResult.OK) return;
            filePath = dlg.FileName;
        }

        try
        {
            var sb = new StringBuilder();
            sb.AppendLine("<!DOCTYPE html><html><head><meta charset='utf-8'/><title>" + _reportTitle + "</title>");
            sb.AppendLine("<style>");
            sb.AppendLine("body { font-family: 'Segoe UI', Arial, sans-serif; margin: 40px; color: #222; }");
            sb.AppendLine(".header { text-align: center; margin-bottom: 25px; }");
            sb.AppendLine(".title { font-size: 22px; font-weight: bold; color: #193F6E; margin-bottom: 6px; }");
            sb.AppendLine(".sub { font-size: 13px; color: #666; }");
            sb.AppendLine("table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 13px; }");
            sb.AppendLine("th { background-color: #193F6E; color: white; padding: 8px; border: 1px solid #ccc; }");
            sb.AppendLine("td { padding: 6px 8px; border: 1px solid #ddd; }");
            sb.AppendLine("tr:nth-child(even) { background-color: #F5F8FC; }");
            sb.AppendLine(".footer { margin-top: 25px; font-size: 12px; color: #777; text-align: right; }");
            sb.AppendLine("</style></head><body>");

            sb.AppendLine("<div class='header'>");
            sb.AppendLine("<div style='font-weight: bold; color: #193F6E;'>TRƯỜNG ĐẠI HỌC CÔNG NGHỆ ĐÔNG Á</div>");
            sb.AppendLine("<div class='title'>" + _reportTitle + "</div>");
            sb.AppendLine("<div class='sub'>Ngày lập: " + DateTime.Now.ToString("dd/MM/yyyy HH:mm") + " | Người lập: Nguyễn Quang Dũng (MSSV: 24003351)</div>");
            sb.AppendLine("</div>");

            if (_dataSource != null && _dataSource.Columns.Count > 0)
            {
                sb.AppendLine("<table><thead><tr>");
                foreach (DataColumn c in _dataSource.Columns) sb.AppendLine("<th>" + c.ColumnName + "</th>");
                sb.AppendLine("</tr></thead><tbody>");
                foreach (DataRow r in _dataSource.Rows)
                {
                    sb.AppendLine("<tr>");
                    foreach (var val in r.ItemArray) sb.AppendLine("<td>" + (val?.ToString() ?? "") + "</td>");
                    sb.AppendLine("</tr>");
                }
                sb.AppendLine("</tbody></table>");
            }

            sb.AppendLine("<div class='footer'>Trang 1/1 - Crystal Report HTML Output</div>");
            sb.AppendLine("</body></html>");

            File.WriteAllText(filePath, sb.ToString(), Encoding.UTF8);
            if (string.IsNullOrEmpty(targetFilePath))
            {
                MessageBox.Show($"Đã xuất file HTML thành công!\n{filePath}", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Lỗi xuất HTML: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private static void SaveBitmapAsPdf(Bitmap bmp, string pdfPath, string title)
    {
        // Convert bitmap to JPEG bytes
        using var ms = new MemoryStream();
        bmp.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
        byte[] imgBytes = ms.ToArray();

        int imgWidth = bmp.Width;
        int imgHeight = bmp.Height;

        using var fs = new FileStream(pdfPath, FileMode.Create, FileAccess.Write);
        using var writer = new StreamWriter(fs, Encoding.ASCII);

        // Minimalist valid PDF with embedded image
        var offsets = new System.Collections.Generic.List<long>();
        writer.Write("%PDF-1.4\r\n");
        writer.Flush();

        // Object 1: Catalog
        offsets.Add(fs.Position);
        writer.Write("1 0 obj\r\n<< /Type /Catalog /Pages 2 0 R >>\r\nendobj\r\n");
        writer.Flush();

        // Object 2: Pages
        offsets.Add(fs.Position);
        writer.Write("2 0 obj\r\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\r\nendobj\r\n");
        writer.Flush();

        // Object 3: Page
        offsets.Add(fs.Position);
        writer.Write("3 0 obj\r\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /XObject << /Im1 4 0 R >> >> /Contents 5 0 R >>\r\nendobj\r\n");
        writer.Flush();

        // Object 4: Image XObject
        offsets.Add(fs.Position);
        writer.Write($"4 0 obj\r\n<< /Type /XObject /Subtype /Image /Width {imgWidth} /Height {imgHeight} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length {imgBytes.Length} >>\r\nstream\r\n");
        writer.Flush();
        fs.Write(imgBytes, 0, imgBytes.Length);
        writer.Write("\r\nendstream\r\nendobj\r\n");
        writer.Flush();

        // Object 5: Content stream (display image on 595x842 pt A4)
        string content = "q\r\n595 0 0 842 0 0 cm\r\n/Im1 Do\r\nQ\r\n";
        byte[] contentBytes = Encoding.ASCII.GetBytes(content);
        offsets.Add(fs.Position);
        writer.Write($"5 0 obj\r\n<< /Length {contentBytes.Length} >>\r\nstream\r\n{content}endstream\r\nendobj\r\n");
        writer.Flush();

        // XRef table
        long xrefPos = fs.Position;
        writer.Write($"xref\r\n0 6\r\n0000000000 65535 f \r\n");
        foreach (var off in offsets)
        {
            writer.Write($"{off:D10} 00000 n \r\n");
        }
        writer.Write($"trailer\r\n<< /Size 6 /Root 1 0 R >>\r\nstartxref\r\n{xrefPos}\r\n%%EOF\r\n");
        writer.Flush();
    }

    private void PrintReport()
    {
        try
        {
            using var printDoc = new PrintDocument();
            printDoc.DocumentName = _reportTitle;
            printDoc.PrintPage += (s, ev) =>
            {
                if (ev.Graphics != null)
                {
                    PaperPage_Paint(this, new PaintEventArgs(ev.Graphics, ev.MarginBounds));
                }
            };
            using var dlg = new PrintDialog { Document = printDoc };
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                printDoc.Print();
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Lỗi in ấn: {ex.Message}", "Lỗi in", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
