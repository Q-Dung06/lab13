using System.Configuration;
using System.Data.SqlClient;

namespace Lab13.DAL;

public static class DbConnectionFactory
{
    private const string DefaultConnectionString =
        "Data Source=.\\SQLEXPRESS;Initial Catalog=QLSinhVien;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;Connect Timeout=8;Application Name=Lab13_CrystalReport";

    public static SqlConnection Create()
    {
        return new SqlConnection(GetConnectionString());
    }

    public static string GetConnectionString()
    {
        var configured = ConfigurationManager.ConnectionStrings["QLSinhVien"]?.ConnectionString;
        return string.IsNullOrWhiteSpace(configured) ? DefaultConnectionString : configured;
    }
}
