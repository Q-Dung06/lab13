using System.Data;
using System.Data.SqlClient;

namespace Lab13.DAL;

public sealed class BaoCaoDAL
{
    // Bài 2 & 3: Lấy dữ liệu báo cáo danh sách sinh viên
    public DataTable GetStudentReportData()
    {
        var table = new DataTable("SinhVienReport");
        using var conn = DbConnectionFactory.Create();
        using var adapter = new SqlDataAdapter("SELECT * FROM dbo.vw_BaoCaoSinhVien ORDER BY TenKhoa, HoTen", conn);
        adapter.Fill(table);
        return table;
    }

    // Bài 6: Lấy dữ liệu báo cáo danh sách khoa kèm số lượng sinh viên
    public DataTable GetFacultyReportData()
    {
        var table = new DataTable("KhoaReport");
        using var conn = DbConnectionFactory.Create();
        using var adapter = new SqlDataAdapter("SELECT * FROM dbo.vw_BaoCaoKhoa ORDER BY MaKhoa", conn);
        adapter.Fill(table);
        return table;
    }

    // Bài 8: Lấy dữ liệu báo cáo danh sách học phần sắp xếp theo tên
    public DataTable GetCourseReportData()
    {
        var table = new DataTable("HocPhanReport");
        using var conn = DbConnectionFactory.Create();
        using var adapter = new SqlDataAdapter("SELECT * FROM dbo.vw_BaoCaoHocPhan ORDER BY TenHP", conn);
        adapter.Fill(table);
        return table;
    }

    // Bài 1 & 10: Kiểm tra kết nối và lấy thông tin phiên bản SQL Server
    public string GetServerInfo()
    {
        using var conn = DbConnectionFactory.Create();
        conn.Open();
        using var cmd = new SqlCommand("SELECT @@VERSION", conn);
        return cmd.ExecuteScalar()?.ToString() ?? string.Empty;
    }
}
