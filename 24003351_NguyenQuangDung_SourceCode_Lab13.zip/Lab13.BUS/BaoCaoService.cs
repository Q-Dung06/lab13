using System.Data;
using Lab13.DAL;

namespace Lab13.BUS;

public sealed class BaoCaoService
{
    private readonly BaoCaoDAL _dal = new();

    public DataTable GetStudentReport()
    {
        return _dal.GetStudentReportData();
    }

    public DataTable GetFacultyReport()
    {
        return _dal.GetFacultyReportData();
    }

    public DataTable GetCourseReport()
    {
        return _dal.GetCourseReportData();
    }

    public string GetServerInfo()
    {
        return _dal.GetServerInfo();
    }
}
