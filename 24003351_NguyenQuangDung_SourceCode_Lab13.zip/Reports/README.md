# Đặc tả báo cáo – Lab 13

Thư mục này chứa 3 PDF mẫu xuất trực tiếp từ ứng dụng và đặc tả thiết kế của 3 báo cáo.
Do máy thực hành chưa cài SAP Crystal Reports runtime, project dùng `ReportViewerPanel`
(engine nội bộ tương thích quy trình Crystal Reports). Các đặc tả dưới đây đủ để tái tạo
lại báo cáo bằng Crystal Reports Designer nếu có runtime.

## 1. Danh mục báo cáo

| Mã báo cáo | Tên báo cáo | Nguồn dữ liệu | Sắp xếp | Tệp PDF |
|---|---|---|---|---|
| `CR-RPT-SV-01` | Báo cáo Danh sách Sinh viên | `vw_BaoCaoSinhVien` | `TenKhoa, HoTen` | `DanhSachSinhVien.pdf` |
| `CR-RPT-KHOA-02` | Báo cáo Danh sách Khoa | `vw_BaoCaoKhoa` | `MaKhoa` | `DanhSachKhoa.pdf` |
| `CR-RPT-HP-03` | Báo cáo Danh sách Học phần | `vw_BaoCaoHocPhan` | `TenHP` | `DanhSachHocPhan.pdf` |

## 2. Bố cục chung (A4 Portrait)

- Khổ giấy: A4 Portrait, lề trái/phải 40 px, lề trên 35 px, lề dưới 40 px.
- **Report Header:**
  - Logo trường (huy hiệu chữ E).
  - `TRƯỜNG ĐẠI HỌC CÔNG NGHỆ ĐÔNG Á`
  - `KHOA CÔNG NGHỆ THÔNG TIN – BỘ MÔN CÔNG NGHỆ PHẦN MỀM`
  - `HỌC PHẦN: LẬP TRÌNH .NET (IT3212)`
  - Đường kẻ đôi màu xanh navy/teal.
  - Tiêu đề báo cáo căn giữa.
  - `Ngày lập báo cáo: dd/MM/yyyy HH:mm | Người lập: Nguyễn Quang Dũng (MSSV: 24003351)`.
- **Page Header:** dòng tiêu đề cột, nền xanh navy, chữ trắng.
- **Details:** các dòng dữ liệu, nền xen kẽ trắng/#F5F8FC, đường kẻ #E1E6F0.
- **Report Footer:** dòng tổng số, ngày lập, chữ ký/xác nhận.
- **Page Footer:** mã báo cáo, `Trang 1 / 1`, tên engine.
- Định dạng: ngày `dd/MM/yyyy`; điểm `N2` (2 chữ số thập phân); tiêu đề cột in đậm.

## 3. Báo cáo Sinh viên (`CR-RPT-SV-01`)

**Câu truy vấn nguồn**
```sql
SELECT *
FROM dbo.vw_BaoCaoSinhVien
ORDER BY TenKhoa, HoTen;
```

**Cột trên báo cáo**

| STT | Field | Tiêu đề | Độ rộng (px) | Định dạng |
|---|---|---|---|---|
| 1 | `STT` | STT | 36 | Số thứ tự, canh giữa |
| 2 | `MaSV` | Mã SV | 62 | Text |
| 3 | `HoTen` | Họ và tên | 145 | Text |
| 4 | `NgaySinh` | Ngày sinh | 80 | `dd/MM/yyyy`, canh giữa |
| 5 | `GioiTinh` | Phái | 42 | Text, canh giữa |
| 6 | `TenKhoa` | Khoa | 155 | Text |
| 7 | `DiemTB` | ĐTB | 45 | `N2`, canh phải |
| 8 | `Email` | Email | 175 | Text |

- Tổng số dòng: 30 sinh viên (1 trang A4).
- Dòng tổng: `Tổng số sinh viên trong báo cáo: 30 sinh viên`.

## 4. Báo cáo Khoa (`CR-RPT-KHOA-02`)

**Câu truy vấn nguồn**
```sql
SELECT *
FROM dbo.vw_BaoCaoKhoa
ORDER BY MaKhoa;
```

**Cột trên báo cáo**

| STT | Field | Tiêu đề | Độ rộng (px) | Định dạng |
|---|---|---|---|---|
| 1 | `STT` | STT | 60 | Canh giữa |
| 2 | `MaKhoa` | Mã khoa | 140 | Text |
| 3 | `TenKhoa` | Tên khoa | 280 | Text |
| 4 | `SoLuongSinhVien` | Số lượng SV | 130 | Số nguyên, canh giữa |
| 5 | `DiemTrungBinhKhoa` | Điểm TB khoa | 130 | `N2`, canh phải |

- Dòng tổng: `Tổng số khoa đào tạo: 3 khoa`.

## 5. Báo cáo Học phần (`CR-RPT-HP-03`)

**Câu truy vấn nguồn**
```sql
SELECT *
FROM dbo.vw_BaoCaoHocPhan
ORDER BY TenHP;
```

**Cột trên báo cáo**

| STT | Field | Tiêu đề | Độ rộng (px) | Định dạng |
|---|---|---|---|---|
| 1 | `STT` | STT | 60 | Canh giữa |
| 2 | `MaHP` | Mã học phần | 140 | Text |
| 3 | `TenHP` | Tên học phần (Sắp xếp theo tên) | 320 | Text |
| 4 | `SoTinChi` | Số tín chỉ | 100 | Số nguyên, canh giữa |
| 5 | `SoSinhVienDangKy` | Số SV đăng ký | 120 | Số nguyên, canh giữa |

- Dòng tổng: `Tổng số học phần trong chương trình đào tạo: 5 học phần`.

## 6. Tái tạo bằng SAP Crystal Reports (nếu có runtime)

1. Mở Visual Studio, cài **SAP Crystal Reports for Visual Studio** và runtime x86/x64 phù hợp.
2. Thêm mới **Crystal Report** vào project `Lab13_CrystalReport`.
3. Chọn **Create New Connection → OLE DB (ADO)** hoặc **Database Expert**, trỏ tới CSDL `QLSinhVien`.
4. Chọn view tương ứng (`vw_BaoCaoSinhVien`, `vw_BaoCaoKhoa`, `vw_BaoCaoHocPhan`).
5. Kéo các field vào section **Details** theo đúng thứ tự và độ rộng trong bảng trên.
6. Đặt tiêu đề cột vào **Page Header**, logo/tên trường/ngày lập vào **Report Header**,
   dòng tổng vào **Report Footer**, số trang vào **Page Footer**.
7. Định dạng field:
   - `NgaySinh`: Format Field → Date → `dd/MM/yyyy`.
   - `DiemTB`, `DiemTrungBinhKhoa`: Number → 2 decimal places.
   - `SoLuongSinhVien`, `SoTinChi`, `SoSinhVienDangKy`: Number → 0 decimal places.
8. Lưu lần lượt thành:
   - `SinhVienReport.rpt`
   - `KhoaReport.rpt`
   - `HocPhanReport.rpt`
9. Trong form, thay `ReportViewerPanel` bằng `CrystalReportViewer`:
```csharp
private ReportDocument _report;
private void frmBaoCaoSinhVien_Load(object sender, EventArgs e)
{
    var data = new BaoCaoService().GetStudentReport();
    _report = new SinhVienReport();
    _report.SetDataSource(data);
    crystalReportViewer1.ReportSource = _report;
    crystalReportViewer1.Refresh();
}
protected override void OnFormClosed(FormClosedEventArgs e)
{
    _report?.Close();
    _report?.Dispose();
    base.OnFormClosed(e);
}
```
10. Xuất PDF:
```csharp
using var dlg = new SaveFileDialog { Filter = "PDF file|*.pdf", FileName = "DanhSachSinhVien.pdf" };
if (dlg.ShowDialog() == DialogResult.OK)
{
    _report.ExportToDisk(ExportFormatType.PortableDocFormat, dlg.FileName);
}
```

## 7. Ghi chú
- Các file `.design.xml` trong thư mục `Design` là đặc tả kỹ thuật do project tự sinh,
  **không phải** file `.rpt` nhị phân của SAP. Chúng dùng để đối chiếu bố cục khi chấm bài.
- Khi có SAP Crystal Reports runtime, có thể dùng các đặc tả này để tạo lại `.rpt` đúng 100%.
