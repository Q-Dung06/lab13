/* Lab 13: Cac view va du lieu mau cho Crystal Report trong QLSinhVien */
USE QLSinhVien;
GO

-- 1. View bao cao sinh vien (Bai 2)
CREATE OR ALTER VIEW dbo.vw_BaoCaoSinhVien
AS
SELECT 
    sv.MaSV,
    sv.HoTen,
    sv.NgaySinh,
    CASE sv.GioiTinh WHEN 1 THEN N'Nam' ELSE N'Nữ' END AS GioiTinh,
    k.MaKhoa,
    k.TenKhoa,
    sv.DiemTB,
    sv.Email,
    sv.IsActive
FROM dbo.SinhVien sv
JOIN dbo.Khoa k ON sv.MaKhoa = k.MaKhoa;
GO

-- 2. View bao cao danh sach khoa kem so luong sinh vien (Bai 6)
CREATE OR ALTER VIEW dbo.vw_BaoCaoKhoa
AS
SELECT 
    k.MaKhoa,
    k.TenKhoa,
    COUNT(CASE WHEN sv.IsActive = 1 THEN sv.MaSV ELSE NULL END) AS SoLuongSinhVien,
    ISNULL(ROUND(AVG(CASE WHEN sv.IsActive = 1 THEN sv.DiemTB ELSE NULL END), 2), 0) AS DiemTrungBinhKhoa
FROM dbo.Khoa k
LEFT JOIN dbo.SinhVien sv ON k.MaKhoa = sv.MaKhoa
GROUP BY k.MaKhoa, k.TenKhoa;
GO

-- 3. View bao cao danh sach hoc phan sap xep theo ten (Bai 8)
CREATE OR ALTER VIEW dbo.vw_BaoCaoHocPhan
AS
SELECT 
    hp.MaHP,
    hp.TenHP,
    hp.SoTinChi,
    COUNT(dk.MaSV) AS SoSinhVienDangKy
FROM dbo.HocPhan hp
LEFT JOIN dbo.DangKy dk ON hp.MaHP = dk.MaHP
GROUP BY hp.MaHP, hp.TenHP, hp.SoTinChi;
GO

-- 4. Bo sung du lieu mau dam bao >= 20 sinh vien theo yeu cau Chuan bi truoc khi thuc hanh
IF (SELECT COUNT(*) FROM dbo.SinhVien) < 20
BEGIN
    INSERT INTO dbo.SinhVien(MaSV, HoTen, NgaySinh, GioiTinh, MaKhoa, DiemTB, Email, IsActive)
    VALUES
    ('SV011', N'Lê Minh Tuấn', '2004-02-14', 1, 'CNTT', 8.20, 'tuan.lm@eaut.edu.vn', 1),
    ('SV012', N'Đặng Thu Hà', '2004-09-25', 0, 'CNTT', 9.15, 'ha.dt@eaut.edu.vn', 1),
    ('SV013', N'Ngô Gia Bảo', '2003-12-05', 1, 'OTO', 7.45, 'bao.ng@eaut.edu.vn', 1),
    ('SV014', N'Bùi Phương Thảo', '2004-05-18', 0, 'KT', 8.60, 'thao.bp@eaut.edu.vn', 1),
    ('SV015', N'Trịnh Đình Trọng', '2003-11-30', 1, 'CNTT', 7.90, 'trong.td@eaut.edu.vn', 1),
    ('SV016', N'Dương Khánh Linh', '2004-08-12', 0, 'KT', 8.75, 'linh.dk@eaut.edu.vn', 1),
    ('SV017', N'Vũ Đức Thắng', '2004-04-01', 1, 'OTO', 8.10, 'thang.vd@eaut.edu.vn', 1),
    ('SV018', N'Lý Hải Yến', '2003-07-22', 0, 'CNTT', 9.30, 'yen.lh@eaut.edu.vn', 1),
    ('SV019', N'Hà Văn Nam', '2004-01-19', 1, 'KT', 7.65, 'nam.hv@eaut.edu.vn', 1),
    ('SV020', N'Nguyễn Quang Dũng', '2004-06-15', 1, 'CNTT', 9.50, 'dung.nq24003351@eaut.edu.vn', 1);
END;
GO
